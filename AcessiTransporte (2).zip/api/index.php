<?php
header('Content-Type: application/json');
require_once 'database.php';

$method = $_SERVER['REQUEST_METHOD'];
$path = explode('/', trim($_SERVER['PATH_INFO'] ?? '', '/'));

if ($path[0] === 'rides') {
    $db = Database::connect();
    if ($method === 'GET') {
        echo json_encode($db->query("SELECT * FROM rides")->fetchAll(PDO::FETCH_ASSOC));
    }
    if ($method === 'POST') {
        $data = json_decode(file_get_contents("php://input"), true);
        $stmt = $db->prepare("INSERT INTO rides (origin,destination,price) VALUES (?,?,?)");
        $stmt->execute([$data['origin'],$data['destination'],$data['price']]);
        echo json_encode(['success'=>true]);
    }
    exit;
}

echo json_encode(['api'=>'AcessiTransporte']);
