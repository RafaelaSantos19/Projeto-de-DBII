<?php
require_once __DIR__ . '/../database.php';
$db = Database::connect();

$db->exec("CREATE TABLE IF NOT EXISTS rides (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    origin TEXT,
    destination TEXT,
    price REAL
)");
echo json_encode(['status'=>'ok']);
